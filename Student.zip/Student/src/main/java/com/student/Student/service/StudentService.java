package com.student.Student.service;

import java.util.List;

import com.student.Student.model.Student;

public interface StudentService {

List<Student> getAllStudents();
	
Student getStudent(int rno);
	
	Student saveStudent(Student student);
	
	Student updateStudent(int rno ,Student student);
	
	boolean deleteStudent(int rno);


}