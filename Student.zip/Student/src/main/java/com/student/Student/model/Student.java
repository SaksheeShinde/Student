package com.student.Student.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Student")
@JsonInclude(value = Include.NON_NULL)
public class Student implements Serializable {

	@Id
	@Column(name="rno")
	private int rno;
	
	@Column(name="name")
	private String name;
	
	@Column(name="percentage")
	private float percentage;
	
	@Column(name="sclass")
	private String sclass;
	
	@Column(name="college")
	private String college;

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int rno, String name, float percentage, String sclass, String college) {
		super();
		this.rno = rno;
		this.name = name;
		this.percentage = percentage;
		this.sclass = sclass;
		this.college = college;
	}

	public int getRno() {
		return rno;
	}

	public void setRno(int rno) {
		this.rno = rno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public String getSclass() {
		return sclass;
	}

	public void setSclass(String sclass) {
		this.sclass = sclass;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	@Override
	public String toString() {
		return "Student [rno=" + rno + ", name=" + name + ", percentage=" + percentage + ", sclass=" + sclass
				+ ", college=" + college + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(college, name, percentage, rno, sclass);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(college, other.college) && Objects.equals(name, other.name)
				&& Float.floatToIntBits(percentage) == Float.floatToIntBits(other.percentage) && rno == other.rno
				&& Objects.equals(sclass, other.sclass);
	}

	
}