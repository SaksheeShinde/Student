 package com.student.Student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.Student.dao.StudentDao;
import com.student.Student.model.Student;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDao studentDao;
	
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}

	@Override
	public Student getStudent(int rno) {
		// TODO Auto-generated method stub
		Optional<Student>studentOp = studentDao.findById(rno);
		return studentOp.get();
	}

	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDao.save(student);
	}

	@Override
	public Student updateStudent(int rno, Student student) {
		// TODO Auto-generated method stub
		Optional<Student>studentOp = studentDao.findById(student.getRno());
        Student studentFromDB = studentOp.get();
        studentFromDB.setRno(student.getRno());
       
        studentFromDB.setName(student.getName());
        studentFromDB.setPercentage(student.getPercentage());
        studentFromDB.setCollege(student.getCollege());


    Student savedc = studentDao.save(studentFromDB);
		return savedc;
	}

	public boolean deleteStudent(int rno) {
		// TODO Auto-generated method stub
		Optional<Student>studentOp = studentDao.findById(rno);
		if (studentOp.isPresent()) {
			studentDao.delete(studentOp.get());
			return true;
		}

		return false;
	}

	

	
		
	
	

}