package com.student.Student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.Student.model.Student;
import com.student.Student.service.StudentService;

import jakarta.annotation.security.PermitAll;


@RestController
@RequestMapping(value = "/student")
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	@GetMapping(produces = "application/json")
	@PermitAll
	public ResponseEntity<List<Student>> getAllStudents()
	{
		List<Student> studentList = studentService.getAllStudents();
		ResponseEntity<List<Student>> response =
				new ResponseEntity<List<Student>>(studentList,HttpStatusCode.valueOf(200));
		return response;
	}
	
	@PostMapping(produces = "application/json")
	@PermitAll
	public ResponseEntity <Student> saveStudent(@RequestBody Student student)
	{
		Student stud =studentService.saveStudent(student);
		ResponseEntity <Student> response = 
		new ResponseEntity <Student>(stud,HttpStatusCode.valueOf(200));
		return response;	    
	}
	
	@GetMapping(value = "/{rno}",produces = "application/json")
	public ResponseEntity<Student> getStudent(@PathVariable("rno")int rno)
	{
		Student student=studentService.getStudent(rno);
		ResponseEntity<Student> response =
		new ResponseEntity<Student>(student, HttpStatusCode.valueOf(200));
		return response;
		
	}
	
	@PutMapping(value = "/{rno}",produces = "application/json")
	@PermitAll
	public ResponseEntity<Student> updateStudent(@PathVariable("rno")int rno, @RequestBody Student student)
	{
		Student stud=studentService.updateStudent(rno, student);
		ResponseEntity<Student> response =
		new ResponseEntity<Student>(stud,HttpStatusCode.valueOf(200));
		return response;
		
	}
	
	@DeleteMapping(value = "/{rno}", produces = "application/json")
	public ResponseEntity<String> deleteStudent(@PathVariable("rno") int rno)
	{
		boolean res = studentService.deleteStudent(rno);
		String message;
		int status;
		if(res == true)
		{
		message = "student deleted!";
		status = 200;
		
		} else {
			message = "unable to delete!";
			status = 400;
		}
		ResponseEntity<String> response = 
				new ResponseEntity<String>(message, HttpStatusCode.valueOf(status));
		return response;
		
	}

}
